<?php
// Heading
$_['heading_title']           = 'Tools';

// Text
$_['text_install']            = 'Install';
$_['text_uninstall']          = 'Uninstall';
$_['text_open']               = 'Open';

// Column
$_['column_name']             = 'Tool Name';
$_['column_description']      = 'Tool Description';
$_['column_action']           = 'Action';

// Error
$_['error_permission']        = 'Warning: You do not have permission to modify Tools!';
?>