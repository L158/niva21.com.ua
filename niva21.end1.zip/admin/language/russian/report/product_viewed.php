<?php
// Heading
$_['heading_title']  = 'Отчет по просмотренным товарам';

// Text
$_['text_success']   = 'Список просмотренных товаров очищен!';

// Column
$_['column_name']    = 'Название товара';
$_['column_model']   = 'Модель';
$_['column_viewed']  = 'Просмотров';
$_['column_percent'] = 'Процент';
?>