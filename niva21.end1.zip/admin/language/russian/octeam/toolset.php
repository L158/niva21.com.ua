<?php
// Heading
$_['heading_title']           = 'Инструменты';

// Text
$_['text_install']            = 'Установить';
$_['text_uninstall']          = 'Удалить';
$_['text_open']               = 'Открыть';

// Column
$_['column_name']             = 'Название Инструмента';
$_['column_description']      = 'Описание Инструмента';
$_['column_action']           = 'Действие';

// Error
$_['error_permission']        = 'У Вас нет прав для управления Инструментами!';
?>