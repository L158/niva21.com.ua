<?php
// Heading
$_['heading_title']    = 'Черный список IP';

// Text
$_['text_success']     = 'Черный список IP успешно изменен!';

// Column
$_['column_ip']        = 'IP';
$_['column_customer']  = 'Покупатель';
$_['column_action']    = 'Действие';

// Entry
$_['entry_ip']         = 'IP:';

// Error
$_['error_permission'] = 'У Вас нет прав для изменения Черного списка IP!';
$_['error_ip']         = 'IP должен быть от 1 до 15 символов!';
?>