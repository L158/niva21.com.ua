<?php
// Heading
$_['heading_title'] = 'Журнал ошибок';

// Text
$_['text_success']  = 'Журнал ошибок очищен!';
?>